﻿Public Class Form1
    Dim lv As New ListViewItem
    Dim selected As String
    Private Sub resetForm()
        txtProductID.Text = ""
        txtProductName.Text = ""
        txtProductPrice.Text = ""
        txtProductCategory.Text = ""
        txtProductQuantity.Text = ""

        txtProductID.Enabled = False
        txtProductName.Enabled = False
        txtProductPrice.Enabled = False
        txtProductCategory.Enabled = False
        txtProductQuantity.Enabled = False

        btnClose.Text = "Close"
        btnNewEdit.Text = "New"
        btnNewEdit.Enabled = True
        btnSaveUpdate.Enabled = False
        btnDelete.Enabled = False

    End Sub

    Private Sub PopListView()
        ListView1.Clear()

        With ListView1
            .View = View.Details
            .GridLines = True
            .Columns.Add("Product ID", 100)
            .Columns.Add("Product Name", 120)
            .Columns.Add("Product Price", 120)
            .Columns.Add("Product Category", 120)
            .Columns.Add("Product Quantity", 120)
        End With

        openCon()
        sql = "select * from tblProducts"
        cmd = New OleDb.OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader

        Do While dr.Read() = True
            lv = New ListViewItem(dr("product_ID").ToString)
            lv.SubItems.Add(dr("productName"))
            lv.SubItems.Add(dr("productPrice"))
            lv.SubItems.Add(dr("productCategory"))
            lv.SubItems.Add(dr("productQuantity"))
            ListView1.Items.Add(lv)
        Loop

        cn.Close()
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        resetForm()
        PopListView()
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        resetForm()
        Dim i As Integer
        For i = 0 To ListView1.SelectedItems.Count - 1

            selected = ListView1.SelectedItems(i).Text
            openCon()

            sql = "Select * from tblProducts WHERE product_ID = " & selected & ""
            cmd = New OleDb.OleDbCommand(sql, cn)
            dr = cmd.ExecuteReader

            dr.Read()
            txtProductID.Text = dr("product_ID")
            txtProductName.Text = dr("productName")
            txtProductPrice.Text = dr("productPrice")
            txtProductCategory.Text = dr("productCategory")
            txtProductQuantity.Text = dr("productQuantity")
            cn.Close()
        Next

        btnClose.Text = "Cancel"
        btnNewEdit.Text = "Edit"
        btnSaveUpdate.Text = "Update"
        btnNewEdit.Enabled = True
        btnSaveUpdate.Enabled = False
        btnDelete.Enabled = True
    End Sub

    Private Sub btnNewEdit_Click(sender As Object, e As EventArgs) Handles btnNewEdit.Click
        If btnNewEdit.Text = "New" Then
            txtProductID.Enabled = True
            txtProductName.Enabled = True
            txtProductPrice.Enabled = True
            txtProductCategory.Enabled = True
            txtProductQuantity.Enabled = True

            btnClose.Text = "Cancel"
            btnSaveUpdate.Enabled = True
        Else
            txtProductID.Enabled = False
            txtProductName.Enabled = True
            txtProductPrice.Enabled = True
            txtProductCategory.Enabled = True
            txtProductQuantity.Enabled = True

            btnClose.Text = "Cancel"
            btnSaveUpdate.Enabled = True
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        If btnClose.Text = "Cancel" Then
            Me.resetForm()
        Else
            btnClose.Text = "Close"
            Me.Close()
        End If
    End Sub

    Private Sub btnSaveUpdate_Click(sender As Object, e As EventArgs) Handles btnSaveUpdate.Click
        If txtProductID.Text = "" Or txtProductName.Text = "" Or txtProductPrice.Text = "" Or txtProductCategory.Text = "" Or txtProductQuantity.Text = "" Then
            MsgBox("Please complete all data before saving! ", 48, Me.Text)
        Else
            If btnSaveUpdate.Text = "Save" Then
                If MsgBox("Are you sure to save this record? ", vbYes + vbQuestion, Me.Text) Then
                    openCon()
                    sql = "INSERT INTO tblProducts (product_ID, productName, productPrice, productCategory, productQuantity) VALUES " _
                        & "('" & Me.txtProductID.Text & "', '" & Me.txtProductName.Text & "', '" & Me.txtProductPrice.Text & "', " _
                        & "'" & Me.txtProductCategory.Text & "', '" & Me.txtProductQuantity.Text & "')"
                    cmd = New OleDb.OleDbCommand(sql, cn)
                    cmd.ExecuteNonQuery()
                    cn.Close()
                    MsgBox("Record Saved! ", 64, Me.Text)

                    PopListView()
                    resetForm()
                End If
            Else
                If MsgBox("Are you sure you want to update this record? ", vbYes + vbQuestion, Me.Text) Then
                    openCon()
                    sql = "UPDATE tblProducts SET productName = '" & Me.txtProductName.Text & "', productPrice = '" & Me.txtProductPrice.Text & "', productCategory = '" & Me.txtProductCategory.Text & "', productQuantity = '" & Me.txtProductQuantity.Text & "' WHERE product_ID = " & selected & ""
                    cmd = New OleDb.OleDbCommand(sql, cn)
                    cmd.ExecuteNonQuery()
                    cn.Close()
                    MsgBox("Record Updated!", 64, Me.Text)

                    PopListView()
                    resetForm()
                End If
            End If
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MsgBox("Are you sure to delete this record? ", vbYesNo + vbQuestion, Me.Text) = vbYes Then
            openCon()
            sql = "DELETE FROM tblProducts WHERE product_ID = " & selected & ""
            cmd = New OleDb.OleDbCommand(sql, cn)
            cmd.ExecuteNonQuery()
            cn.Close()
            MsgBox("Record Deleted!", 64, Me.Text)

            PopListView()
            resetForm()
        End If
    End Sub
End Class
