﻿Imports System.Data
Imports System.Data.OleDb

Module Module1
    Public cn As New OleDbConnection
    Public cmd As New OleDbCommand
    Public dr As OleDbDataReader
    Public sql As String

    Public Sub openCon()
        cn.ConnectionString = ("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\ProductDB.accdb")

        If cn.State = ConnectionState.Closed Then
            cn.Open()
        End If
    End Sub

End Module
